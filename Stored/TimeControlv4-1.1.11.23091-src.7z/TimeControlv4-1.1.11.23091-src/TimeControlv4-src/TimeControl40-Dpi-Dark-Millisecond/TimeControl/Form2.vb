﻿Imports System.Runtime.InteropServices
Public Class Form2
    <DllImport("dwmapi.dll")> _
    Public Shared Function DwmSetWindowAttribute(ByVal hwnd As IntPtr, ByVal attr As DwmWindowAttribute, ByRef attrValue As Integer, ByVal attrSize As Integer) As Integer
    End Function
    'Public Shared Function EnableDarkModeForWindow(ByVal hWnd As IntPtr, ByVal enable As Boolean) As Boolean
    '    Dim darkMode As Integer
    '    darkMode = enable
    '    Dim hr As Integer
    '    Dim i As Integer
    '    'hr = DwmSetWindowAttribute(hWnd, DwmWindowAttribute.UseImmersiveDarkMode, darkMode, sizeof(i))
    '    Return hr >= 0
    'End Function
    Public Shared Function EnableDarkModeForWindow(ByVal hWnd As IntPtr, ByVal enable As Boolean) As Boolean
        Dim attrValue As Integer = If(enable, 1, 0)
        Return (Form1.DwmSetWindowAttribute(hWnd, DwmWindowAttribute.UseImmersiveDarkMode, attrValue, 4) >= 0)
    End Function

    Public Enum DwmWindowAttribute As UInt32
        NCRenderingEnabled = 1
        NCRenderingPolicy
        TransitionsForceDisabled
        AllowNCPaint
        CaptionButtonBounds
        NonClientRtlLayout
        ForceIconicRepresentation
        Flip3DPolicy
        ExtendedFrameBounds
        HasIconicBitmap
        DisallowPeek
        ExcludedFromPeek
        Cloak
        Cloaked
        FreezeRepresentation
        PassiveUpdateMode
        UseHostBackdropBrush
        UseImmersiveDarkMode = 20
        WindowCornerPreference = 33
        BorderColor
        CaptionColor
        TextColor
        VisibleFrameBorderThickness
        SystemBackdropType
        Last
    End Enum

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        On Error GoTo errcode
        If RadioButton1.Checked = True Then
            If TextBox1.Text = "" Then
                MsgBox("隐藏时间不能为空！", MsgBoxStyle.Critical, "错误")
            ElseIf TextBox1.Text = "0" Then
                MsgBox("隐藏时间不能为0！", MsgBoxStyle.Critical, "错误")
            Else
                If ComboBox1.SelectedIndex = 0 Then '秒
                    Form1.Timer2.Interval = TextBox1.Text * 1000
                    Form1.Timer2.Enabled = True
                    Form1.Hide()
                    Me.Close()
                ElseIf ComboBox1.SelectedIndex = 1 Then '分
                    Form1.Timer2.Interval = TextBox1.Text * 1000 * 60
                    Form1.Timer2.Enabled = True
                    Form1.Hide()
                    Me.Close()
                ElseIf ComboBox1.SelectedIndex = 2 Then '时
                    Form1.Timer2.Interval = TextBox1.Text * 1000 * 60 * 60
                    Form1.Timer2.Enabled = True
                    Form1.Hide()
                    Me.Close()
                End If
            End If
        ElseIf RadioButton2.Checked = True Then
            End
        End If
        Exit Sub
errcode:
        MsgBox(Err.Description, MsgBoxStyle.Critical, "错误")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 0
        ComboBox1.SelectedText = "秒"
        Label1.Text = "时间小工具 版本：" & My.Application.Info.Version.ToString & vbCrLf & "版权所有 © 2023 CJH。保留所有权利。"
        Call formatcolorcurset()
    End Sub
    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        Dim strlimit As String
        strlimit = "0123456789"
        Dim keychar As Char = e.KeyChar
        If InStr(strlimit, keychar) <> 0 Or e.KeyChar = Microsoft.VisualBasic.ChrW(8) Then
            'If keychar = "." And InStr(TextBox1.Text, keychar) <> 0 Then
            'e.Handled = True
            'Else
            e.Handled = False
            'End If
        Else
            e.Handled = True
        End If
    End Sub
    Sub formatcolorcurset()
        If Form1.crmd = 0 Then
            EnableDarkModeForWindow(Me.Handle, True)
            Me.BackColor = Color.Black
            Me.ForeColor = Color.White
            Me.Button1.BackColor = Color.Black
            Me.Button1.ForeColor = Color.White
            Me.Button2.BackColor = Color.Black
            Me.Button2.ForeColor = Color.White
            Me.TextBox1.BackColor = Color.Black
            Me.TextBox1.ForeColor = Color.White
            Me.ComboBox1.BackColor = Color.Black
            Me.ComboBox1.ForeColor = Color.White
            Me.RadioButton1.BackColor = Color.Black
            Me.RadioButton1.ForeColor = Color.White
            Me.RadioButton2.BackColor = Color.Black
            Me.RadioButton2.ForeColor = Color.White
        Else
            EnableDarkModeForWindow(Me.Handle, False)
            Me.BackColor = Color.White
            Me.ForeColor = Color.Black
            Me.Button1.BackColor = Color.Transparent
            Me.Button1.ForeColor = Color.Black
            Me.Button2.BackColor = Color.Transparent
            Me.Button2.ForeColor = Color.Black
            Me.TextBox1.BackColor = Color.White
            Me.TextBox1.ForeColor = Color.Black
            Me.ComboBox1.BackColor = Color.White
            Me.ComboBox1.ForeColor = Color.Black
            Me.RadioButton1.BackColor = Color.White
            Me.RadioButton1.ForeColor = Color.Black
            Me.RadioButton2.BackColor = Color.White
            Me.RadioButton2.ForeColor = Color.Black
        End If
    End Sub
End Class